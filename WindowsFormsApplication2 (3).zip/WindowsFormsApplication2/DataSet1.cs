﻿namespace WindowsFormsApplication2 {
    
    
    public partial class DataSet1 {
    }
}
